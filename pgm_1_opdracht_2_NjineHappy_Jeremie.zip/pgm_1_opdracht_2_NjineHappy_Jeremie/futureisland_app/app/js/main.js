void (() => {
  const app = {
    initialize: function () {
      console.log(` Application started `);
      this.getDomElements();
      this.getLineUp();
      this.getNavigation();
      this.getEventListener();
    },

    getDomElements: function () {
      this.$lineUpContainer = document.querySelector(".lineup__container");
      this.$concertDetailsContainer = document.querySelector(
        ".concert__details"
      );

      this.$navigationContainer = document.querySelector(
        ".navigation__container"
      );
      this.$filteredContainerLinks = document.querySelectorAll(
        ".concert--filter__days"
      );
      this.$removeConcertDetailsButton = document.querySelector(
        "#removeConcertDetails"
      );
    },
    getNavigation: function () {
      this.$navigationContainer.innerHTML = this.navigationPage(navigation);
    },
    navigationPage: function (navigation) {
      return navigation.map((navi, i) => this.getNavItem(navi)).join(" ");
    },
    getNavItem: function (navItem) {
      return ` <a href="${navItem.link}" ${
        navItem.type === "external"
          ? 'target="_blank" rel="noreferrer noopener"'
          : 'target="_self"'
      } ">${navItem.name}</a>`;
    },
    getLineUp: function () {
      this.$lineUpContainer.innerHTML = this.concertPage(lineUp);
      this.$lineUpArtistNames = this.$lineUpContainer.querySelectorAll(
        ".lineup__container"
      );
    },

    concertPage: function (lineUp) {
      return lineUp
        .map((concert, i) => this.getOnePerformanceHTML(concert))
        .join(" ");
    },

    getOnePerformanceHTML: function (performance) {
      return ` <article class="performance" data-id="${
        performance.id
      }" data-day="${performance.from}">
            <h1 style="cursor: pointer">${performance.artist.artistName}</h1>
            <div> 
             <p>${this.findWeekdayByMilis(performance.from)}</p>
             <img alt="${performance.artist.artistName}" src = "${
        performance.artist.artistPicture.small
      }">
             <p>${performance.place.placeName}</p>
            </div>
            </article>`;
    },
    getEventListener: function () {
      console.log("eventListenerStarted");

      this.$lineUpArtistNames = document.querySelectorAll("h1");
      console.log(document.querySelectorAll("h1").length);
      if (this.$lineUpArtistNames.length <= 0) {
        console.log("array is zero");
      }

      this.$lineUpArtistNames.forEach(($h1ArtistName, i) => {
        $h1ArtistName.addEventListener("click", (event) => {
          const id = event.target.parentNode.dataset.id;
          console.log(id);
          this.showConcertDetails(id);
        });
      });

      this.$filteredContainerLinks.forEach(($filtered, i) => {
        $filtered.addEventListener("click", (event) => {
          console.log(event.target.dataset.day);
          this.filterLineUpByDay(event.target.dataset.day);
        });
      });

      this.$removeConcertDetailsButton.addEventListener("click", (event) => {
        this.$concertDetailsContainer.innerHTML = " ";
      });
    },

    showConcertDetails: function (id) {
      const performance = lineUp.find((performance) => performance.id === id);
      this.$concertDetailsContainer.innerHTML = ` <br>
      <img  alt="${performance.artist.artistName}" src = "${performance.artist.artistPicture.large}"> 
       The following details are from "${performance.artist.artistName}" <br>
       <h2> Synopsis:</h2>${performance.artist.artistSynopsis} <br>
       <iframe class="video" 
       src="${performance.artist.artistMedia.sourceId}">
       </iframe>
       <ul><h2> Meer weten ?</h2> <li><a href="${performance.artist.artistSocial.website}" class="socialMedia__website">Website</a></li> <br>
       <li><a href="${performance.artist.artistSocial.facebook}" class="socialMedia--facebook">Facebook</a></li> <br>
       <li><a href="${performance.artist.artistSocial.twitter}" class="socialMedia--twitter">Twitter</a></li> <br>
       <li><a href="${performance.artist.artistSocial.instagram}" class="socialMedia--instagram">Instagram</a></li> <br></ul> 
      `;
    },

    filterLineUpByDay: function () {
      const $performancesInHTML = this.$lineUpContainer.querySelectorAll(
        ".performance"
      );
      $performancesInHTML.forEach(($performance, i) => {
        const weekday = this.findWeekdayByMilis(
          parseInt($performance.dataset.day)
        );
        console.log(weekday);
      });
    },

    findWeekdayByMilis: function (timeInMilis) {
      return new Date(timeInMilis).toLocaleString("nl-BE", { weekday: "long" });
    },
  };

  app.initialize();
})();
