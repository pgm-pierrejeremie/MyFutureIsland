const navigation = [
  {
    name: `HOME`,
    link: `https://www.rockwerchter.be/nl/`,
    type: ` internal`,
  },
  {
    name: `LINE UP`,
    link: `https://www.rockwerchter.be/nl/line-up`,
    type: ` internal`,
  },
  {
    name: `TICKETS`,
    link: `https://www.rockwerchter.be/nl/ticket-info`,
    type: ` internal`,
  },
  {
    name: `PRAKTISCH`,
    link: `https://www.rockwerchter.be/nl/praktisch`,
    type: ` internal`,
  },
  {
    name: `CAMPING`,
    link: `https://www.rockwerchter.be/nl/camping`,
    type: ` internal`,
  },
  {
    name: `HISTORY`,
    link: `https://www.rockwerchter.be/nl/geschiedenis`,
    type: ` internal`,
  },
  {
    name: `RWTV`,
    link: `https://www.proximus.be/pickx/nl/festivals/rockwerchter/vod`,
    type: ` external`,
  },
  {
    name: `NMW`,
    link: `http://northwestwalls.be/`,
    type: ` external`,
  },
  {
    name: `KOOP TICKETS`,
    link: `https://www.ticketmaster.be/feature/rockwerchter/`,
    type: ` external`,
  },
];

const lineUp = [
  {
    id: ` c619f190-75e5-4d90-9634-fd68381111ca`,
    artist: {
      artistName: ` GORILLAZ `,
      artistSynopsis: ` Iedereen was het er in 2018 over eens na het concert van Gorillaz in Werchter. Het geesteskind van stripmaker Jamie Hewlett en Damon Albarn van Blur is een van de strafste live-acts ooit. Een greep uit de krantenkoppen: ‘Zoveel grandeur’. ‘Een aanstekelijke apekermis’. ‘Swingend naar een betere wereld’. Albarn kondigde kort nadien aan dat er de komende 10 jaar niet teveel moest verwacht worden. En kijk: in januari van dit jaar presenteren ze het muziekconcept ‘Song machine’. En volgend jaar gaat de eerste virtuele groep uit de geschiedenis weer op reis. Gorillaz brengt vanaf nu muziek uit in afleveringen. Die worden gelost van zodra er nieuw materiaal is. Elke episode heeft een andere gast. De lijst is heel uiteenlopend. Zo deden in 2020 slowthai, Fatoumata Diaware, Peter Hook (New Order), Georgia en Octavian al mee.`,
      artistSocial: {
        website: ` https://www.gorillaz.com/`,
        facebook: ` https://www.facebook.com/Gorillaz `,
        twitter: ` https://www.twitter.com/gorillaz`,
        instagram: ` https://www.instagram.com/gorillaz`,
      },

      artistPicture: {
        small: ` https://assets.rockwerchter.be/files/cache/medium/files/gorillaz-5f030ee8605de.jpg `,
        large: `https://assets.rockwerchter.be/files/cache/medium/files/gorillaz-5f030ee8605de.jpg`,
      },

      artistMedia: [
        {
          type: `video`,
          sourceld: `https://www.youtu.be/O1ALIgizTcc`,
        },
      ],
    },
    place: {
      placeName: `KLUB C`,
    },
    from: 1603708293016,
    to: 1603708333139,
    createdAt: 1603708541367,
    modifiedAt: 1603708565862,
    isHeadliner: true,
  },
  {
    id: ` 77f89f7e-db01-412f-9d58-2f1e952c58ac`,
    artist: {
      artistName: ` PEARL JAM `,
      artistSynopsis: ` Uitstel is geen afstel. Pearl Jam en Rock Werchter zijn voor mekaar gemaakt. Elke passage van de Amerikanen is nog beter. Pearl Jam toert in juni en juli 2021 kort door Europa. Amper 15 concerten staan op de planning. `,
      artistSocial: {
        website: ` https://pearljam.com/`,
        facebook: ` https://www.facebook.com/pearljam `,
        twitter: `https://www.twitter.com/pearljam`,
        instagram: ` https://www.instagram.com/pearljam`,
      },

      artistPicture: {
        small: `https://assets.rockwerchter.be/files/cache/medium/files/14686-pearl-jam-032020-6c9a9964-flat-lowres-5f1a952633f63.jpg `,
        large: `https://assets.rockwerchter.be/files/cache/medium/files/14686-pearl-jam-032020-6c9a9964-flat-lowres-5f1a952633f63.jpg `,
      },

      artistMedia: [
        {
          type: `video`,
          sourceld: `https://youtu.be/qM0zINtulhM`,
        },
      ],
    },
    place: {
      placeName: `MAIN STAGE`,
    },
    from: 1604257448394,
    to: 1603708333139,
    createdAt: 1603708541367,
    modifiedAt: 1603708565862,
    isHeadliner: true,
  },
  {
    id: ` 157e7a2b-f9a0-4b27-899e-83b766e4033d`,
    artist: {
      artistName: ` BLACK PUMAS `,
      artistSynopsis: ` Alsof soulzanger Sam Cooke en oerrocker Neil Young lid geworden zijn van hiphopcollectief Wu-Tang Clan. Dat is een ruwe schets van Black Pumas, het project van een bijzonder duo uit de Texaanse hoofdstad Austin. Adrian Quesada is een veertiger die vroeger gitaar speelde bij Grupo Fantasma. Die negenkoppige bende wint in 2010 een Grammy Award voor Best Latin Album. Quesada had in zijn studio enkele instrumentale stukken liggen waar hij een soulstem voor zocht. Vrienden raadden hem Eric Burton aan, een busker die in downtown Austin speelde. Bingo! Het debuut van Black Pumas is zo goed als feilloos. De psychedelische soul bombardeerde de twee in de VS tot ‘breakout band of 2019’. Prima spul alleszins voor wie de voorbije jaren in Werchter genoten heeft van Alabama Shakes, Durand Jones & The Indications of Curtis Harding. `,
      artistSocial: {
        website: ` https://www.theblackpumas.com/`,
        facebook: ` https://www.facebook.com/theblackpumas `,
        twitter: ` https://www.twitter.com/blackpumasmusic`,
        instagram: ` `,
      },

      artistPicture: {
        small: `https://assets.rockwerchter.be/files/cache/medium/files/black-pumas-5f030ee9dc31d.jpg `,
        large: `https://assets.rockwerchter.be/files/cache/medium/files/black-pumas-5f030ee9dc31d.jpg`,
      },

      artistMedia: [
        {
          type: `video`,
          sourceld: `https://www.youtube.com/embed/2EntxPIULUI?rel=0`,
        },
      ],
    },
    place: {
      placeName: `KLUB C`,
    },
    from: 1604257448394,
    to: 1603708333139,
    createdAt: 1603708541367,
    modifiedAt: 1603708565862,
    isHeadliner: true,
  },
  {
    id: ` 62b0a97b-b619-49c4-82bb-46f04008f3e1`,
    artist: {
      artistName: ` ALT-J `,
      artistSynopsis: ` Tik Alt en J in op een toetsenbord van Apple en je krijgt Δ, de Griekse letter delta. Dat teken gebruikt men in de wiskunde en de fysica om de veranderingen van grootheden aan te geven. Met een lichte vrijheid kan je zeggen dat alt-J iets gelijkaardigs doet met de popgeschiedenis. Het Britse trio verzamelt de topmomenten van de afgelopen 60 jaar en zet die om in een eigen universum. Het is daarin even bedreven en vindingrijk als Sigur Rós of The xx. In Werchter komt hun sprookjesachtige wereld duidelijk goed tot haar recht. Dit schreef Humo na hun eerste doortocht in 2013: ‘Hoeveel tergende schoonheid kan een mens aan, en hoeveel suikerige ontroering? In The Barn veranderde alt-J uw leven.’ En dit zag Moustique in 2015: ‘alt_J rentre dans la cour des grands.’ Sinds hun laatste doortocht in 2017 is het veelbelovend stil rond alt-J… `,
      artistSocial: {
        website: ` https://www.altjband.com/`,
        facebook: ` https://www.facebook.com/altJ.band `,
        twitter: ` https://www.twitter.com/alt_J`,
        instagram: ` https://www.instagram.com/unrealalt`,
      },

      artistPicture: {
        small: ` https://assets.rockwerchter.be/files/cache/medium/files/alt-j-5f030ee72f4ba.jpg`,
        large: ` https://assets.rockwerchter.be/files/cache/medium/files/alt-j-5f030ee72f4ba.jpg`,
      },

      artistMedia: [
        {
          type: `video`,
          sourceld: "https://www.youtube.com/embed/GOJUNJ1o394?",
        },
      ],
    },
    place: {
      placeName: `KLUB C`,
    },
    from: 1603708293016,
    to: 1603708333139,
    createdAt: 1603708541367,
    modifiedAt: 1603708565862,
    isHeadliner: true,
  },
  {
    id: ` 6d5a75bb-4a0b-42ec-b044-a4fbebd73f63`,
    artist: {
      artistName: ` GIRL IN RED `,
      artistSynopsis: ` Marie Ulven Ringheim beseft in september 2017 dat ze stapelverliefd is op haar beste vriendin. Ze ziet haar in de verte op een concert en stuurt het sms-bericht ‘girl in red’. Er komt uiteindelijk niets van. Maar dat moment van opwinding en verlangen stuurt vanaf dan heel sterk haar muziek, zegt de Noorse twintiger. Ze had meteen ook een naam voor de liedjes die ze in haar slaapkamer maakt op de gitaar die ze als tiener als kerstcadeau kreeg van haar grootvader. Haar eerste single ‘I Wanna Be Your Girlfriend’ wordt bij de beste liedjes van 2018 gerekend. Hij vertaalt de verzuchtingen van veel van haar leeftijdsgenoten en maakt van Ringheim een baken binnen de LGBT-gemeenschap. Dat lijkt misschien gewichtig maar haar liedjes zijn in de eerste plaats heel lichtvoetig en grappig. In oktober brengt ze haar debuutplaat ‘World In Red’ uit. `,
      artistSocial: {
        website: ` https://www.worldinred.com/`,
        facebook: `  `,
        twitter: ` https://www.twitter.com/_girlinred_`,
        instagram: ` `,
      },

      artistPicture: {
        small: `https://assets.rockwerchter.be/files/cache/medium/files/girl-in-redd-1-5f030ee7c3796.jpg `,
        large: `https://assets.rockwerchter.be/files/cache/medium/files/girl-in-redd-1-5f030ee7c3796.jpg`,
      },

      artistMedia: [
        {
          type: `video`,
          sourceld: `http://www.youtube.com/embed/Pzq4TEU-wHo?rel=0`,
        },
      ],
    },
    place: {
      placeName: `KLUB C`,
    },
    from: 1603708293016,
    to: 1603708333139,
    createdAt: 1603708541367,
    modifiedAt: 1603708565862,
    isHeadliner: true,
  },
];

const social = [
  {
    socialName: `Facebook`,
    socialLink: `https://www.facebook.com/rockwerchterfestival`,
    socialType: `Facebook`,
  },
  {
    socialName: `Twitter`,
    socialLink: `http://www.twitter.com/rockwerchter`,
    socialType: `Twitter`,
  },
  {
    socialName: `Instagram`,
    socialLink: `http://instagram.com/rockwerchterfestival`,
    socialType: `Instagram`,
  },
  {
    socialName: `Spotify`,
    socialLink: `https://play.spotify.com/user/rockwerchterofficial`,
    socialType: `Spotify`,
  },
  {
    socialName: `YouTube`,
    socialLink: `http://www.youtube.com/user/rockwerchterfestival`,
    socialType: `YouTube`,
  },
];
